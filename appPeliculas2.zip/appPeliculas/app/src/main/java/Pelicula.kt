
class Pelicula(val id: Int, var nombre:String, var desc:String, var imagen:Int ) {

}
