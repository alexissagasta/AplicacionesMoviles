package sagasta.alexis.apppeliculas

import Pelicula
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView

class MainActivity : AppCompatActivity() {
    var peliculas:ArrayList<Pelicula> = ArrayList();
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        agregarPeliculas();
        val adaptador: AdaptadorPeliculas= AdaptadorPeliculas(this,peliculas)

        val listView: ListView = findViewById(R.id.listView)

        listView.adapter= adaptador
    }



    fun agregarPeliculas(){
        peliculas.add(Pelicula(1,"Venom","Un alien cae del cielo y le da poderes a Tom Hardy",R.drawable.c));
        peliculas.add(Pelicula(2,"Buscando a nemo","Un pez payaso busca a su hijo por todo el oceano acompañado de un pez olvidadizo",R.drawable.poster));
        peliculas.add(Pelicula(3,"Iron man","Un millonario llamado Tony Stark es secuestrado por un grupo terrorista y crea la armadura que protejera el mundo",R.drawable.a));
        peliculas.add(Pelicula(4,"Avengers: Endgame","Los vengadores buscan arreglar el desastre que creo Tanos y para ello tienen que viajar en el tiempo",R.drawable.b));
    }

}